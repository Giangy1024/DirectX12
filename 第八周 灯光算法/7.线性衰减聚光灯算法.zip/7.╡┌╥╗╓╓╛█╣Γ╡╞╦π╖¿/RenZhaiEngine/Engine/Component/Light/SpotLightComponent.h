#pragma once
#include "Core/RangeLightComponent.h"

class CSpotLightComponent :public CRangeLightComponent
{
	typedef CRangeLightComponent Super;
public:
	CSpotLightComponent();
};
