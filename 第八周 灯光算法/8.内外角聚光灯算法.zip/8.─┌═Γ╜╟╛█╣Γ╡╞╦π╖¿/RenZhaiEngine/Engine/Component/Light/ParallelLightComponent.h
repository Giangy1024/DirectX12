#pragma once
#include "Core/LightComponent.h"

class CParallelLightComponent :public CLightComponent
{
	typedef CLightComponent Super;
public:
	CParallelLightComponent();
};
