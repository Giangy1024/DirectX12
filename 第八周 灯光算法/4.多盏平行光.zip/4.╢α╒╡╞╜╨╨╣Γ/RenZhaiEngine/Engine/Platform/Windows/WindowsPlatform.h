#pragma once

#ifndef FORCEINLINE
#define FORCEINLINE __forceinline	
#endif // !FORCEINLINE