#pragma once
#include "../Core/RenderingEngine.h"

class CVulkanRenderingEngine :public CRenderingEngine
{
public:



};