#pragma once

enum ELightType
{
	DirectionalLight,//ƽ�й�
	SpotLight,
};