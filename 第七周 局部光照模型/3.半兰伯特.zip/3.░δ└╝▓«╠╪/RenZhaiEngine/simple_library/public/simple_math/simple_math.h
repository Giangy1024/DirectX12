// Copyright (C) RenZhai.2022.All Rights Reserved.
#pragma once
#include "../simple_core_minimal/simple_c_core/simple_core_minimal.h"

_CRT_BEGIN_C_HEADER
unsigned int get_uint32_random(unsigned int in_max);

_CRT_END_C_HEADER
