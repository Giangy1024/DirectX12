#pragma once
#include "Core/DirectXRenderingEngine.h"

class CDirectX11RenderingEngine :public CDirectXRenderingEngine
{
public:



};