#include "ShellMeshComponent.h"
#include "../../Mesh/Core/MeshType.h"

CShellMeshComponent::CShellMeshComponent()
{

}
