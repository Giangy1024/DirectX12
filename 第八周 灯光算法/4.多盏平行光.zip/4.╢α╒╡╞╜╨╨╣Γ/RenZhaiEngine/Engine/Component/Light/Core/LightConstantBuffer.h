#pragma once
#include "../../../EngineMinimal.h"

struct FLight
{
	XMFLOAT3 LightIntensity;
	float XX = 0.f;
	XMFLOAT3 LightDirection;
	float XX1 = 0.f;
};

struct FLightConstantBuffer
{
	FLightConstantBuffer();

	FLight SceneLights[16];
};
