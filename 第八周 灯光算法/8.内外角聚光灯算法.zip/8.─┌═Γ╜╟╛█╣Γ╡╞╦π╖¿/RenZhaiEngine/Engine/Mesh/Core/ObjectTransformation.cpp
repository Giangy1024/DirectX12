#include "ObjectTransformation.h"

FObjectTransformation::FObjectTransformation()
    :World(EngineMath::IdentityMatrix4x4())
{

}