#pragma once
#include "Core/RangeLightComponent.h"

class CPointLightComponent :public CRangeLightComponent
{
	typedef CRangeLightComponent Super;
public:
	CPointLightComponent();
};
