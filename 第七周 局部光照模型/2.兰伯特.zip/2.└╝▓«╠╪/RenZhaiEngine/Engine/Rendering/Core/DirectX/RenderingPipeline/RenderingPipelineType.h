#pragma once

enum EPipelineState
{
	GrayModel = 4,
	Wireframe = 5,
};