#pragma once
#include "Core/MeshComponent.h"

class CShellMeshCompnent :public CMeshComponent
{
public:
	CShellMeshCompnent();

};
