// Copyright (C) RenZhai.2022.All Rights Reserved.
#pragma once
#include "../../../public/simple_channel/simple_core/simple_connetion.h"

class FSimpleTCPConnetion :public FSimpleConnetion
{
public:


};