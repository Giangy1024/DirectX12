#include "InputType.h"

FInputKey::FInputKey()
	:PressState(EPressState::Press)
{

}