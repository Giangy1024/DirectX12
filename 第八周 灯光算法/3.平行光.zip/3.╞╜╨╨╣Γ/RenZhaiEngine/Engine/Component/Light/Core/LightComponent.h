#pragma once
#include "../../TransformationComponent.h"
#include "../../../Interface/DirectXDeviceInterfece.h"

class CMeshComponent;
class CLightComponent :public CTransformationComponent,public IDirectXDeviceInterfece
{
	typedef CTransformationComponent Super;

	CVARIABLE()
	CMeshComponent* LightMesh;
public:
	CLightComponent();

	virtual ~CLightComponent();

	CMeshComponent* GetLightMesh() { return LightMesh; }

	virtual void SetPosition(const XMFLOAT3& InNewPosition);
	virtual void SetRotation(const fvector_3d& InNewRotation);
	virtual void SetScale(const fvector_3d& InNewScale);

	virtual void SetForwardVector(const XMFLOAT3& InForwardVector);
	virtual void SetRightVector(const XMFLOAT3& InRightVector);
	virtual void SetUPVector(const XMFLOAT3& InUPVector);

protected:
	void SetLightMesh(CMeshComponent *InLightMesh);
};
