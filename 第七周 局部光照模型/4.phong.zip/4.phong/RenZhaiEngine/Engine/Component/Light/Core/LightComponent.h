#pragma once
#include "../../TransformationComponent.h"

class CLightComponent :public CTransformationComponent
{

};
