#pragma once
#include "Core/Component.h"

class CTransformationComponent :public CComponent
{
public:


};
