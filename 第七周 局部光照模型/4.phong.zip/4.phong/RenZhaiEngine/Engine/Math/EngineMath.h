#pragma once
#include "../EngineMinimal.h"
#include <DirectXMath.h>

namespace EngineMath
{
	XMFLOAT4X4 IdentityMatrix4x4();
}
