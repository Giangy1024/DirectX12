#pragma once

enum EMaterialType
{
	Lambert = 0,
	HalfLambert,
	Phong,
	Max,
};