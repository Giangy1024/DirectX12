#include "Mesh.h"
#include "../../Config/EngineRenderConfig.h"
#include "../../Component/TransformationComponent.h"
#include "Material/Material.h"
#include "../../Component/Mesh/ShellMeshCompnent.h"

GMesh::GMesh()
	:GActorObject()
{
	ShellMeshCompnent = CreateObject<CShellMeshCompnent>(new CShellMeshCompnent());
	
}

void GMesh::Init()
{
	if (ShellMeshCompnent)
	{
		ShellMeshCompnent->Init();
	}
}

void GMesh::BuildMesh(const FMeshRenderingData* InRenderingData)
{
	if (ShellMeshCompnent)
	{
		ShellMeshCompnent->BuildMesh(InRenderingData);
	}
}

void GMesh::PreDraw(float DeltaTime)
{

}

void GMesh::Draw(float DeltaTime)
{
}

void GMesh::PostDraw(float DeltaTime)
{
}

UINT GMesh::GetMaterialNum() const
{
	return ShellMeshCompnent->GetMaterialNum();
}

vector<CMaterial*>* GMesh::GetMaterials()
{
	return ShellMeshCompnent->GetMaterials();
}
