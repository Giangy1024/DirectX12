#include "RangeLightComponent.h"

CRangeLightComponent::CRangeLightComponent()
	:Super()
	, StartAttenuation(1.f)
	, EndAttenuation(10.f)
{
}
