#pragma once

enum ECmeraType
{
	CameraRoaming,
	ObservationObject,
};