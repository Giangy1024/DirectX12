#pragma once
#include "../../../EngineMinimal.h"

struct FLightConstantBuffer
{
	FLightConstantBuffer();

	XMFLOAT3 LightIntensity;
	float XX = 0.f;
	XMFLOAT3 LightDirection;
	float XX1 = 0.f;
};
