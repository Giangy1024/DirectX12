#include "Mesh.h"
#include "../../Config/EngineRenderConfig.h"
#include "../../Component/TransformationComponent.h"

GMesh::GMesh()
	:GActorObject()
{
	
}

void GMesh::Init()
{
}

void GMesh::BuildMesh(const FMeshRenderingData* InRenderingData)
{
}

void GMesh::PreDraw(float DeltaTime)
{
}

void GMesh::Draw(float DeltaTime)
{
}

void GMesh::PostDraw(float DeltaTime)
{
}
