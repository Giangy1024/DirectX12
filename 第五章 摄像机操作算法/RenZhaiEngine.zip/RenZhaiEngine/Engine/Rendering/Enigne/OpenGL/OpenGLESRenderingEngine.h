#pragma once
#include "../Core/RenderingEngine.h"

class COpenGLESRenderingEngine :public CRenderingEngine
{
public:



};