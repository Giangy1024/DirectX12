// Copyright (C) RenZhai.2022.All Rights Reserved.
#pragma once
#include <vector>

using namespace std;
namespace math_utils
{
	void Save_bmp(const vector<char>& data);
}