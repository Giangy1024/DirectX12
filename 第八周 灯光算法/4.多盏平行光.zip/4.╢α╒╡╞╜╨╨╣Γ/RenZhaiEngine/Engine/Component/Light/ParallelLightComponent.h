#pragma once
#include "Core/LightComponent.h"

class CMeshComponent;
class CParallelLightComponent :public CLightComponent
{

public:
	CParallelLightComponent();
};
