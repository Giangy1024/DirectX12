#include "ShellMeshCompnent.h"

CShellMeshCompnent::CShellMeshCompnent()
{

}
