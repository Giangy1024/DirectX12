#pragma once
#include "../../../Core/CoreObject/CoreMinimalObject.h"

class CMaterial :public CCoreMinimalObject
{
public:
};