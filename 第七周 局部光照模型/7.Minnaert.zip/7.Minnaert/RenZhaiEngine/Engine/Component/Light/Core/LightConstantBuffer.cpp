#include "LightConstantBuffer.h"

FLightConstantBuffer::FLightConstantBuffer()
	:LightIntensity(1.f,1.f,1.f)
	,LightDirection(0.f,-1.f,0.f)
{
}
