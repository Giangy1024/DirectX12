#include "LightManage.h"

void CLightManage::AddLight(CLightComponent* InLightStance)
{
	Lights.push_back(InLightStance);
}
