#pragma once

#if defined(_WIN32)
#include "../../Core/Engine.h"
#include "../../Rendering/Enigne/Core/RenderingEngine.h"

class CDirectXRenderingEngine;
class CWorld;

class CWindowsEngine :public CEngine
{
	friend class IDirectXDeviceInterfece;
public:
	CWindowsEngine();
	~CWindowsEngine();

	virtual int PreInit(FWinMainCommandParameters InParameters);

	virtual int Init(FWinMainCommandParameters InParameters);
	virtual int PostInit();

	virtual void Tick(float DeltaTime);

	virtual int PreExit();
	virtual int Exit();
	virtual int PostExit();

	CDirectXRenderingEngine* GetRenderingEngine() { return RenderingEngine; }
public:
	class CMeshManage* GetMeshManage();
public:

	bool InitWindows(FWinMainCommandParameters InParameters);

protected:
	HWND MianWindowsHandle;//��windows���

protected:
	CDirectXRenderingEngine* RenderingEngine;
	CWorld* World;
};
#endif