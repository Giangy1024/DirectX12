#pragma once
#include "Core/MeshComponent.h"

class CShellMeshComponent :public CMeshComponent
{
public:
	CShellMeshComponent();

};
