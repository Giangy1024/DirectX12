#include "MaterialConstantBuffer.h"
#include "../../../Math/EngineMath.h"

FMaterialConstantBuffer::FMaterialConstantBuffer()
	:TransformInformation(EngineMath::IdentityMatrix4x4())
{
}
