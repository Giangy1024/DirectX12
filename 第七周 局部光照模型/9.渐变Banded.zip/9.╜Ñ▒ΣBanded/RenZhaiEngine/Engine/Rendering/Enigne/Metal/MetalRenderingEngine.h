#pragma once
#include "../Core/RenderingEngine.h"

class CMetalRenderingEngine :public CRenderingEngine
{
public:



};