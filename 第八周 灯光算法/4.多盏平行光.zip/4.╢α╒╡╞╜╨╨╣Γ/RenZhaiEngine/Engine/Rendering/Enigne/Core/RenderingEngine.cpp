#include "RenderingEngine.h"

void CRenderingEngine::SetMianWindowsHandle(HWND InNewMianWindowsHandle)
{
	MianWindowsHandle = InNewMianWindowsHandle;
}
